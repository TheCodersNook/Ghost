#include <stdio.h>

#include "esp_err.h"
#include "esp_log.h"
#include "esp_vfs_fat.h"
#include "nvs_flash.h"
#include "wear_levelling.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "tinyusb.h"
#include "tinyusb_msc.h"

#define CACHE_MOUNT_PATH "/cache"
#define CACHE_PARTITION_LABEL "storage"

static const char *TAG = "ghostdrive";
static wl_handle_t s_wl_handle = WL_INVALID_HANDLE;

static void write_setup_file(void)
{
    FILE *file = fopen(CACHE_MOUNT_PATH "/GHOSTDRIVE_SETUP.TXT", "w");
    if (file == NULL) {
        ESP_LOGE(TAG, "Could not create setup file");
        return;
    }
    fputs("GhostDrive setup\r\n================\r\n\r\n", file);
    fputs("This USB disk is a local write-back cache.\r\n", file);
    fputs("Before cloud synchronization can be enabled, add:\r\n", file);
    fputs("CLIENT_ID=your-Microsoft-Entra-application-client-ID\r\n", file);
    fputs("WIFI_SSID=your-network-name\r\n", file);
    fputs("WIFI_PASSWORD=your-network-password\r\n\r\n", file);
    fputs("Safely eject the USB disk before removing it.\r\n", file);
    fputs("The production image must enable ESP32 flash encryption before use.\r\n", file);
    fclose(file);
}

void app_main(void)
{
    ESP_ERROR_CHECK(nvs_flash_init());

    const esp_vfs_fat_mount_config_t mount_config = {
        .format_if_mount_failed = true,
        .max_files = 4,
        .allocation_unit_size = 4096,
    };
    ESP_ERROR_CHECK(esp_vfs_fat_spiflash_mount_rw_wl(
        CACHE_MOUNT_PATH, CACHE_PARTITION_LABEL, &mount_config, &s_wl_handle));
    write_setup_file();

    const tinyusb_msc_storage_config_t storage_config = {
        .wl_handle = s_wl_handle,
    };
    ESP_ERROR_CHECK(tinyusb_msc_storage_init_spiflash(&storage_config));

    const tinyusb_config_t tinyusb_config = {
        .device_descriptor = NULL,
        .string_descriptor = NULL,
        .external_phy = false,
        .configuration_descriptor = NULL,
    };
    ESP_ERROR_CHECK(tinyusb_driver_install(&tinyusb_config));

    ESP_LOGI(TAG, "USB cache disk is ready; cloud sync is disabled until setup is completed.");
    while (true) {
        vTaskDelay(pdMS_TO_TICKS(1000));
    }
}
